"""
modules/subtitle.py
====================
Generates a `.srt` subtitle file from a list of scenes (prompt text used as
the caption) and their durations, so `outputs/subtitle.srt` always matches
the final merged video's timeline.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import List


def _format_timestamp(seconds: float) -> str:
    if seconds < 0:
        seconds = 0
    hours, rem = divmod(seconds, 3600)
    minutes, secs = divmod(rem, 60)
    millis = int(round((secs - int(secs)) * 1000))
    return f"{int(hours):02d}:{int(minutes):02d}:{int(secs):02d},{millis:03d}"


@dataclass
class SubtitleCue:
    text: str
    duration: float  # seconds


def generate_srt(cues: List[SubtitleCue], output_path: Path,
                  max_chars_per_line: int = 60) -> Path:
    """Write an SRT file where each cue spans its scene's duration
    sequentially, starting at t=0.
    """
    lines = []
    t = 0.0
    for i, cue in enumerate(cues, start=1):
        start = _format_timestamp(t)
        end = _format_timestamp(t + cue.duration)
        text = _wrap_text(cue.text, max_chars_per_line)
        lines.append(f"{i}\n{start} --> {end}\n{text}\n")
        t += cue.duration

    output_path.write_text("\n".join(lines), encoding="utf-8")
    return output_path


def _wrap_text(text: str, max_chars: int) -> str:
    words = text.split()
    lines, current = [], ""
    for w in words:
        if len(current) + len(w) + 1 > max_chars:
            lines.append(current)
            current = w
        else:
            current = f"{current} {w}".strip()
    if current:
        lines.append(current)
    return "\n".join(lines[:2])  # keep subtitles to 2 lines max
