"""
modules/scene_generator.py
============================
Orchestrates multi-scene video generation: takes an ordered list of `Scene`
objects (prompt, duration, camera motion, lighting, character, background),
generates each one with `TextToVideoGenerator`, then merges everything into
a single final video with `modules.merge`, plus exports a matching
`subtitle.srt` and a `thumbnail.png`.

This is the engine behind the "Scene Generator" tab in the Gradio app.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, List, Optional

from config import DEFAULT_FPS
from modules.character import Character, CharacterManager
from modules.merge import merge_scenes
from modules.prompt_optimizer import build_negative_prompt, optimize_prompt
from modules.subtitle import SubtitleCue, generate_srt
from modules.text_to_video import TextToVideoGenerator
from modules.utils import (
    estimate_duration,
    format_eta,
    make_thumbnail,
    new_job_dir,
    save_history_entry,
)

logger = logging.getLogger("ai_video_studio.scene_generator")

ProgressCallback = Optional[Callable[[float, str], None]]


@dataclass
class Scene:
    prompt: str
    duration: float = 4.0             # seconds
    camera_motion: str = "static"
    lighting: str = "soft natural light"
    character_name: Optional[str] = None
    background: Optional[str] = None
    seed: int = -1
    fps: int = DEFAULT_FPS
    width: int = 512
    height: int = 512
    guidance_scale: float = 6.0
    steps: int = 25

    def build_full_prompt(self, character: Optional[Character]) -> str:
        parts = [self.prompt]
        if self.background:
            parts.append(f"background: {self.background}")
        parts.append(f"lighting: {self.lighting}")
        parts.append(f"camera motion: {self.camera_motion}")
        if character:
            parts.append(character.to_prompt_fragment())
        return optimize_prompt(", ".join(parts))

    @property
    def num_frames(self) -> int:
        return max(9, int(round(self.duration * self.fps)))


class SceneGenerator:
    """Generates a sequence of scenes and merges them into one final video."""

    def __init__(self, generator: Optional[TextToVideoGenerator] = None):
        self.generator = generator or TextToVideoGenerator()
        self.character_manager = CharacterManager()

    def generate_project(
        self,
        scenes: List[Scene],
        project_name: str = "project",
        add_subtitles: bool = True,
        burn_subtitles: bool = False,
        progress_cb: ProgressCallback = None,
    ) -> dict:
        """Generate every scene, merge them, and export all deliverables.

        Returns a dict with paths: final_video, scene_videos, thumbnail,
        subtitle, job_dir.
        """
        if not scenes:
            raise ValueError("At least one scene is required.")

        job_dir = new_job_dir(prefix=project_name)
        scene_paths: List[Path] = []
        eta = estimate_duration(
            len(scenes),
            seconds_per_scene=sum(s.duration for s in scenes) / len(scenes),
            steps=max(s.steps for s in scenes),
        )
        logger.info("Estimated generation time: %s", format_eta(eta))

        for i, scene in enumerate(scenes, start=1):
            character = (
                self.character_manager.load(scene.character_name)
                if scene.character_name else None
            )
            full_prompt = scene.build_full_prompt(character)
            negative_prompt = build_negative_prompt()

            def _scene_progress(frac: float, msg: str, i=i) -> None:
                if progress_cb:
                    overall = ((i - 1) + frac) / len(scenes)
                    progress_cb(overall, f"Scene {i}/{len(scenes)}: {msg}")

            if progress_cb:
                progress_cb((i - 1) / len(scenes), f"Generating scene {i}/{len(scenes)}...")

            scene_path = job_dir / f"scene_{i}.mp4"
            self.generator.generate(
                prompt=full_prompt,
                negative_prompt=negative_prompt,
                seed=scene.seed,
                width=scene.width,
                height=scene.height,
                num_frames=scene.num_frames,
                fps=scene.fps,
                guidance_scale=scene.guidance_scale,
                num_inference_steps=scene.steps,
                output_path=scene_path,
                progress_cb=_scene_progress,
            )
            scene_paths.append(scene_path)

        if progress_cb:
            progress_cb(0.95, "Merging scenes into final video...")

        final_video_path = job_dir / "video.mp4"
        merge_scenes(scene_paths, final_video_path)

        thumbnail_path = None
        try:
            thumbnail_path = make_thumbnail(final_video_path, job_dir / "thumbnail.png")
        except Exception as e:
            logger.warning("Thumbnail generation failed: %s", e)

        subtitle_path = None
        if add_subtitles:
            cues = [SubtitleCue(text=s.prompt, duration=s.duration) for s in scenes]
            subtitle_path = generate_srt(cues, job_dir / "subtitle.srt")
            if burn_subtitles:
                burned_path = job_dir / "video_subtitled.mp4"
                from modules.merge import add_subtitles_to_video
                try:
                    add_subtitles_to_video(final_video_path, subtitle_path, burned_path)
                    final_video_path = burned_path
                except Exception as e:
                    logger.warning("Subtitle burning failed (%s); keeping clean video.", e)

        save_history_entry({
            "project_name": project_name,
            "num_scenes": len(scenes),
            "prompts": [s.prompt for s in scenes],
            "final_video": str(final_video_path),
        })

        if progress_cb:
            progress_cb(1.0, "Done.")

        return {
            "job_dir": job_dir,
            "final_video": final_video_path,
            "scene_videos": scene_paths,
            "thumbnail": thumbnail_path,
            "subtitle": subtitle_path,
        }
