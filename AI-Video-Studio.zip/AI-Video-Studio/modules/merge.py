"""
modules/merge.py
=================
Merges multiple scene video clips into a single final MP4, with optional
per-scene voiceover mixing and burned-in or sidecar subtitles.

Two merge strategies are provided:
    - `merge_with_moviepy`: flexible (handles mismatched resolutions/fps,
      audio mixing), used by default.
    - `merge_with_ffmpeg_concat`: fast stream-copy concat used when all
      clips already share the same codec/resolution/fps (e.g. all produced
      by the same pipeline in one run) — much quicker, no re-encoding.
"""

from __future__ import annotations

import logging
import subprocess
from pathlib import Path
from typing import List, Optional, Sequence

logger = logging.getLogger("ai_video_studio.merge")


def merge_with_ffmpeg_concat(clip_paths: Sequence[Path], output_path: Path) -> Path:
    """Fast lossless concat via ffmpeg's concat demuxer. Requires all clips
    to share codec/resolution/fps; falls back to moviepy merge on failure.
    """
    output_path = Path(output_path)
    list_file = output_path.parent / f"{output_path.stem}_concat_list.txt"
    list_file.write_text(
        "\n".join(f"file '{Path(p).resolve()}'" for p in clip_paths),
        encoding="utf-8",
    )

    cmd = [
        "ffmpeg", "-y", "-f", "concat", "-safe", "0",
        "-i", str(list_file), "-c", "copy", str(output_path),
    ]
    try:
        subprocess.run(cmd, check=True, capture_output=True)
        logger.info("Merged %d clips via ffmpeg concat -> %s", len(clip_paths), output_path)
        return output_path
    except subprocess.CalledProcessError as e:
        logger.warning("ffmpeg concat failed (%s); falling back to moviepy merge.",
                        e.stderr.decode(errors="ignore")[:300])
        return merge_with_moviepy(clip_paths, output_path)
    finally:
        list_file.unlink(missing_ok=True)


def merge_with_moviepy(
    clip_paths: Sequence[Path],
    output_path: Path,
    voiceover_paths: Optional[Sequence[Optional[Path]]] = None,
    fps: int = 24,
    target_resolution: Optional[tuple] = None,
) -> Path:
    """Concatenate clips (re-encoding as needed to normalize fps/resolution)
    and optionally mix a per-scene voiceover under each clip's audio track.
    """
    from moviepy.editor import (
        CompositeAudioClip,
        VideoFileClip,
        concatenate_videoclips,
    )

    output_path = Path(output_path)
    clips = []
    try:
        for i, path in enumerate(clip_paths):
            clip = VideoFileClip(str(path))
            if target_resolution:
                clip = clip.resize(target_resolution)

            if voiceover_paths and i < len(voiceover_paths) and voiceover_paths[i]:
                from moviepy.editor import AudioFileClip
                voice = AudioFileClip(str(voiceover_paths[i]))
                if clip.audio is not None:
                    audio = CompositeAudioClip([clip.audio, voice])
                else:
                    audio = voice
                clip = clip.set_audio(audio.subclip(0, clip.duration))

            clips.append(clip)

        final = concatenate_videoclips(clips, method="compose")
        final.write_videofile(
            str(output_path), fps=fps, codec="libx264", audio_codec="aac",
            logger=None,
        )
        logger.info("Merged %d clips via moviepy -> %s", len(clips), output_path)
        return output_path
    finally:
        for c in clips:
            c.close()


def add_subtitles_to_video(video_path: Path, srt_path: Path, output_path: Path) -> Path:
    """Burn subtitles into the video using ffmpeg's subtitles filter."""
    cmd = [
        "ffmpeg", "-y", "-i", str(video_path),
        "-vf", f"subtitles={srt_path}",
        "-c:a", "copy", str(output_path),
    ]
    subprocess.run(cmd, check=True, capture_output=True)
    return output_path


def merge_scenes(
    clip_paths: List[Path],
    output_path: Path,
    voiceover_paths: Optional[List[Optional[Path]]] = None,
    prefer_fast_concat: bool = True,
) -> Path:
    """High-level entry point used by SceneGenerator: tries the fast ffmpeg
    concat path first (when no per-scene audio mixing is needed), otherwise
    uses the flexible moviepy path.
    """
    if prefer_fast_concat and not voiceover_paths:
        return merge_with_ffmpeg_concat(clip_paths, output_path)
    return merge_with_moviepy(clip_paths, output_path, voiceover_paths)
