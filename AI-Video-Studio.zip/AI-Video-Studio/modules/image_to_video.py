"""
modules/image_to_video.py
===========================
Image-to-Video pipeline wrapper, mirroring the interface of
`text_to_video.TextToVideoGenerator` so the Gradio app can treat both tabs
uniformly. Animates a still image into a short video clip driven by a text
prompt and a "motion strength" control.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Callable, Optional, Union

from config import (
    ACTIVE_IMAGE2VIDEO_MODEL,
    MODEL_REGISTRY,
    detect_gpu,
    get_quality_preset,
)
from modules.utils import Timer, resize_to_multiple, set_seed, unique_path

logger = logging.getLogger("ai_video_studio.image_to_video")

ProgressCallback = Optional[Callable[[float, str], None]]


class ImageToVideoGenerator:
    """Loads and runs an image-to-video diffusion pipeline (e.g. CogVideoX
    Image-to-Video, or LTX-Video's I2V mode).
    """

    def __init__(self, model_key: str = ACTIVE_IMAGE2VIDEO_MODEL):
        if model_key not in MODEL_REGISTRY:
            raise ValueError(f"Unknown model '{model_key}'. "
                              f"Available: {list(MODEL_REGISTRY)}")
        self.model_key = model_key
        self.model_info = MODEL_REGISTRY[model_key]
        self.gpu = detect_gpu()
        self.preset = get_quality_preset(self.gpu)
        self._pipe = None

    def _load_pipeline(self):
        if self._pipe is not None:
            return self._pipe

        import torch
        from diffusers import DiffusionPipeline

        dtype_map = {
            "float16": torch.float16,
            "bfloat16": torch.bfloat16,
            "float32": torch.float32,
        }
        torch_dtype = dtype_map.get(self.preset.dtype, torch.float16)

        with Timer(f"Loading {self.model_info['repo_id']} ({self.preset.dtype})"):
            pipe = DiffusionPipeline.from_pretrained(
                self.model_info["repo_id"],
                torch_dtype=torch_dtype,
            )

        self._apply_memory_optimizations(pipe)
        self._pipe = pipe
        return pipe

    def _apply_memory_optimizations(self, pipe) -> None:
        if self.preset.enable_xformers:
            try:
                pipe.enable_xformers_memory_efficient_attention()
            except Exception as e:
                logger.warning("xFormers unavailable, skipping (%s).", e)
        for flag, method in (
            (self.preset.enable_attention_slicing, "enable_attention_slicing"),
            (self.preset.enable_vae_slicing, "enable_vae_slicing"),
            (self.preset.enable_vae_tiling, "enable_vae_tiling"),
        ):
            if flag and hasattr(pipe, method):
                getattr(pipe, method)()

        if self.preset.enable_cpu_offload and hasattr(pipe, "enable_model_cpu_offload"):
            pipe.enable_model_cpu_offload()
        elif hasattr(pipe, "to"):
            import torch
            pipe.to("cuda" if torch.cuda.is_available() else "cpu")

    def generate(
        self,
        image: Union[str, Path, "PIL.Image.Image"],
        prompt: str = "",
        motion_strength: float = 0.6,
        seed: int = -1,
        num_frames: int = 49,
        fps: int = 24,
        num_inference_steps: int = 25,
        output_path: Optional[Path] = None,
        progress_cb: ProgressCallback = None,
    ) -> Path:
        """Animate a still image into a video clip.

        `motion_strength` (0-1) is mapped to the pipeline's guidance/strength
        parameter to control how much the scene moves/changes vs. staying
        close to the source image.
        """
        from PIL import Image

        if not isinstance(image, Image.Image):
            image = Image.open(image).convert("RGB")
        image = resize_to_multiple(image)

        num_frames = min(num_frames, self.preset.max_frames)
        num_inference_steps = min(num_inference_steps, self.preset.max_steps)
        motion_strength = max(0.0, min(1.0, motion_strength))

        effective_seed = set_seed(seed)
        pipe = self._load_pipeline()

        import torch
        generator = torch.Generator(
            device="cuda" if torch.cuda.is_available() else "cpu"
        ).manual_seed(effective_seed)

        def _hf_progress(step: int, timestep: int, latents) -> None:
            if progress_cb:
                progress_cb(step / max(num_inference_steps, 1),
                            f"Animating step {step}/{num_inference_steps}")

        with Timer(f"Image-to-video generation ({num_frames} frames)"):
            result = pipe(
                image=image,
                prompt=prompt or None,
                num_frames=num_frames,
                num_inference_steps=num_inference_steps,
                # Different I2V pipelines expose this under different names;
                # both are passed defensively via kwargs when supported.
                strength=motion_strength,
                generator=generator,
                callback=_hf_progress,
                callback_steps=1,
            )

        frames = result.frames[0]
        from diffusers.utils import export_to_video
        output_path = output_path or unique_path(Path("outputs"), "image2video", ".mp4")
        export_to_video(frames, str(output_path), fps=fps)
        logger.info("Saved image-to-video output to %s (seed=%s)", output_path, effective_seed)
        return output_path

    def unload(self) -> None:
        self._pipe = None
        try:
            import torch
            torch.cuda.empty_cache()
        except Exception:
            pass
