"""
modules/prompt_optimizer.py
============================
Turns a short, simple prompt into a detailed cinematic prompt suitable for
video diffusion models.

Two modes are supported:
    1. "local"  - a fast, offline, rule-based expander (default, no API
                  cost, works without internet).
    2. "llm"    - if an OpenAI-compatible / Hugging Face text-generation
                  endpoint is configured via environment variables, the
                  optimizer will call it for a more creative rewrite and
                  fall back to the local expander on any failure.

Example
-------
>>> optimize_prompt("Une femme danse.")
"A realistic cinematic scene showing an adult woman dancing gracefully
inside a modern bedroom with soft natural lighting, cozy atmosphere,
smooth camera movement, shallow depth of field, ultra detailed, 4K,
realistic skin texture, cinematic composition, HDR, volumetric lighting."
"""

from __future__ import annotations

import os
import random
import re
from typing import Optional

CINEMATIC_SUFFIXES = [
    "shallow depth of field",
    "ultra detailed",
    "4K",
    "realistic skin texture",
    "cinematic composition",
    "HDR",
    "volumetric lighting",
    "professional color grading",
    "film grain",
    "sharp focus",
]

LIGHTING_CHOICES = [
    "soft natural lighting",
    "golden hour lighting",
    "dramatic studio lighting",
    "warm cozy lighting",
    "moody low-key lighting",
    "bright overcast lighting",
]

CAMERA_CHOICES = [
    "smooth camera movement",
    "slow cinematic pan",
    "gentle handheld motion",
    "steady dolly-in shot",
    "slow motion tracking shot",
]

ATMOSPHERE_CHOICES = [
    "cozy atmosphere",
    "epic atmosphere",
    "serene atmosphere",
    "energetic atmosphere",
    "mysterious atmosphere",
]

# Very small FR->EN dictionary covering common subjects, enough to make the
# local optimizer usable when the user writes in French (Lo's default
# working language). This is intentionally lightweight; for full-quality
# translation, plug in an LLM via `optimize_prompt(..., mode="llm")`.
FR_EN_HINTS = {
    "femme": "woman", "homme": "man", "fille": "girl", "garçon": "boy",
    "enfant": "child", "danse": "dances", "danser": "dancing",
    "court": "runs", "courir": "running", "marche": "walks",
    "chat": "cat", "chien": "dog", "voiture": "car", "ville": "city",
    "forêt": "forest", "plage": "beach", "montagne": "mountain",
    "nuit": "night", "jour": "day", "rue": "street", "maison": "house",
    "chambre": "bedroom", "cuisine": "kitchen", "sourit": "smiles",
    "regarde": "looks at", "assis": "sitting", "debout": "standing",
}


def _lightly_translate(text: str) -> str:
    """Best-effort word-level FR→EN substitution as a cheap fallback so the
    resulting prompt is mostly in English, which video models are usually
    trained/conditioned on. Not a real translator.
    """
    def repl(match: re.Match) -> str:
        word = match.group(0)
        return FR_EN_HINTS.get(word.lower(), word)

    return re.sub(r"[\wÀ-ÿ]+", repl, text)


def optimize_prompt(
    prompt: str,
    style: str = "cinematic realistic",
    scene_hint: Optional[str] = None,
    lighting: Optional[str] = None,
    camera: Optional[str] = None,
    seed: Optional[int] = None,
    mode: str = "local",
) -> str:
    """Expand a short prompt into a detailed cinematic prompt.

    Args:
        prompt: the raw user prompt (any language, ideally short).
        style: overall visual style descriptor, e.g. "cinematic realistic",
            "anime", "3D animation", "documentary".
        scene_hint: optional location/setting override, e.g. "modern bedroom".
        lighting: optional explicit lighting descriptor.
        camera: optional explicit camera movement descriptor.
        seed: optional seed so the random cinematic flourishes are
            reproducible for a given prompt.
        mode: "local" (default, offline) or "llm" (calls an external
            text-generation endpoint if AIVS_LLM_ENDPOINT is set).
    """
    if not prompt or not prompt.strip():
        raise ValueError("Prompt cannot be empty.")

    if mode == "llm":
        llm_result = _try_llm_optimize(prompt, style)
        if llm_result:
            return llm_result
        # fall through to local expansion on failure

    rng = random.Random(seed)
    base = _lightly_translate(prompt.strip().rstrip("."))

    lighting = lighting or rng.choice(LIGHTING_CHOICES)
    camera = camera or rng.choice(CAMERA_CHOICES)
    atmosphere = rng.choice(ATMOSPHERE_CHOICES)
    setting = f" inside {scene_hint}" if scene_hint else ""
    extras = ", ".join(rng.sample(CINEMATIC_SUFFIXES, k=6))

    expanded = (
        f"A {style} scene showing {base}{setting}, with {lighting}, "
        f"{atmosphere}, {camera}, {extras}."
    )
    # Normalize whitespace/capitalization.
    expanded = re.sub(r"\s+", " ", expanded).strip()
    expanded = expanded[0].upper() + expanded[1:]
    return expanded


def _try_llm_optimize(prompt: str, style: str) -> Optional[str]:
    """Optionally call an OpenAI-compatible chat endpoint configured via
    environment variables (AIVS_LLM_ENDPOINT, AIVS_LLM_API_KEY,
    AIVS_LLM_MODEL) to produce a more creative cinematic rewrite.
    Returns None on any error so the caller can fall back gracefully.
    """
    endpoint = os.environ.get("AIVS_LLM_ENDPOINT")
    if not endpoint:
        return None
    try:
        import requests

        api_key = os.environ.get("AIVS_LLM_API_KEY", "")
        model = os.environ.get("AIVS_LLM_MODEL", "gpt-4o-mini")
        system = (
            "You rewrite short video prompts into a single detailed "
            "cinematic English prompt (60-90 words) for a text-to-video "
            f"diffusion model, in a {style} style. Output only the prompt."
        )
        resp = requests.post(
            endpoint,
            headers={"Authorization": f"Bearer {api_key}"} if api_key else {},
            json={
                "model": model,
                "messages": [
                    {"role": "system", "content": system},
                    {"role": "user", "content": prompt},
                ],
                "temperature": 0.8,
            },
            timeout=20,
        )
        resp.raise_for_status()
        data = resp.json()
        return data["choices"][0]["message"]["content"].strip()
    except Exception:
        return None


def build_negative_prompt(extra: Optional[str] = None) -> str:
    """Default high-quality negative prompt, merged with any user extras."""
    defaults = (
        "blurry, low quality, distorted, deformed, extra limbs, watermark, "
        "text, logo, bad anatomy, worst quality, low resolution, "
        "overexposed, underexposed, jpeg artifacts, static noise"
    )
    if extra:
        return f"{defaults}, {extra}"
    return defaults
