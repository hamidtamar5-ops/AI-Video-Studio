"""
modules/voice.py
=================
Optional text-to-speech voiceover generation for scenes/news clips.

Two backends are supported, auto-selected by availability:
    1. `edge-tts` (preferred): free, high-quality, many languages/voices,
       requires internet access.
    2. `pyttsx3` (offline fallback): lower quality but works without
       internet, useful inside sandboxed/no-network environments.

The output is always a `.mp3`/`.wav` file whose duration can be read back
and used to time-align subtitles or scene durations.
"""

from __future__ import annotations

import asyncio
import logging
from pathlib import Path
from typing import Optional

logger = logging.getLogger("ai_video_studio.voice")

DEFAULT_EDGE_VOICE_FR = "fr-FR-DeniseNeural"
DEFAULT_EDGE_VOICE_EN = "en-US-AriaNeural"
DEFAULT_EDGE_VOICE_AR = "ar-MA-JamalNeural"


def generate_voiceover(
    text: str,
    output_path: Path,
    voice: str = DEFAULT_EDGE_VOICE_FR,
    rate: str = "+0%",
) -> Optional[Path]:
    """Generate a voiceover MP3 for `text`. Returns the output path, or
    None if no TTS backend is available (caller should treat voice as
    optional and continue without it).
    """
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    if _try_edge_tts(text, output_path, voice, rate):
        return output_path
    if _try_pyttsx3(text, output_path):
        return output_path

    logger.warning(
        "No TTS backend available (install edge-tts or pyttsx3). "
        "Skipping voiceover generation."
    )
    return None


def _try_edge_tts(text: str, output_path: Path, voice: str, rate: str) -> bool:
    try:
        import edge_tts
    except ImportError:
        return False

    async def _run():
        communicate = edge_tts.Communicate(text, voice=voice, rate=rate)
        await communicate.save(str(output_path))

    try:
        asyncio.run(_run())
        return output_path.exists()
    except Exception as e:
        logger.warning("edge-tts failed (%s), trying fallback.", e)
        return False


def _try_pyttsx3(text: str, output_path: Path) -> bool:
    try:
        import pyttsx3
    except ImportError:
        return False

    try:
        engine = pyttsx3.init()
        wav_path = output_path.with_suffix(".wav")
        engine.save_to_file(text, str(wav_path))
        engine.runAndWait()
        return wav_path.exists()
    except Exception as e:
        logger.warning("pyttsx3 failed (%s).", e)
        return False


def get_audio_duration(audio_path: Path) -> float:
    """Return audio duration in seconds using moviepy."""
    from moviepy.editor import AudioFileClip

    with AudioFileClip(str(audio_path)) as clip:
        return clip.duration
