"""
modules/utils.py
=================
Shared, dependency-light utility functions used across the whole project:
seeding, timing helpers, filesystem helpers, image helpers, thumbnail
generation and prompt-history persistence.
"""

from __future__ import annotations

import json
import logging
import random
import time
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from config import HISTORY_FILE, OUTPUTS_DIR

logger = logging.getLogger("ai_video_studio")
logging.basicConfig(
    level=logging.INFO,
    format="[%(asctime)s] %(levelname)s %(name)s: %(message)s",
    datefmt="%H:%M:%S",
)


# --------------------------------------------------------------------------- #
# Seeding
# --------------------------------------------------------------------------- #

def set_seed(seed: Optional[int] = None) -> int:
    """Seed python/numpy/torch RNGs for reproducible generations.
    Returns the effective seed used (a random one is generated if None/-1).
    """
    if seed is None or seed < 0:
        seed = random.randint(0, 2**31 - 1)

    random.seed(seed)
    try:
        import numpy as np
        np.random.seed(seed)
    except ImportError:
        pass
    try:
        import torch
        torch.manual_seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(seed)
    except ImportError:
        pass

    return seed


# --------------------------------------------------------------------------- #
# Timing / progress helpers
# --------------------------------------------------------------------------- #

class Timer:
    """Small context manager to measure and log elapsed time of a step."""

    def __init__(self, label: str):
        self.label = label
        self.start = 0.0
        self.elapsed = 0.0

    def __enter__(self):
        self.start = time.time()
        logger.info("Starting: %s", self.label)
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.elapsed = time.time() - self.start
        logger.info("Finished: %s in %.1fs", self.label, self.elapsed)


def estimate_duration(num_scenes: int, seconds_per_scene: float, steps: int,
                       base_seconds_per_step: float = 0.9) -> float:
    """Rough ETA (seconds) shown in the UI before generation starts.
    This is a heuristic, not a hardware-accurate benchmark.
    """
    per_scene = steps * base_seconds_per_step
    return round(num_scenes * per_scene + num_scenes * seconds_per_scene * 0.2, 1)


def format_eta(seconds: float) -> str:
    m, s = divmod(int(seconds), 60)
    return f"{m}m {s}s" if m else f"{s}s"


# --------------------------------------------------------------------------- #
# Filesystem helpers
# --------------------------------------------------------------------------- #

def new_job_dir(prefix: str = "job") -> Path:
    job_id = f"{prefix}_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}"
    path = OUTPUTS_DIR / job_id
    path.mkdir(parents=True, exist_ok=True)
    return path


def unique_path(directory: Path, stem: str, suffix: str) -> Path:
    directory.mkdir(parents=True, exist_ok=True)
    candidate = directory / f"{stem}{suffix}"
    counter = 1
    while candidate.exists():
        candidate = directory / f"{stem}_{counter}{suffix}"
        counter += 1
    return candidate


# --------------------------------------------------------------------------- #
# Prompt history (for the "Historique des prompts" gallery)
# --------------------------------------------------------------------------- #

def _load_history() -> List[Dict[str, Any]]:
    if not HISTORY_FILE.exists():
        return []
    try:
        return json.loads(HISTORY_FILE.read_text(encoding="utf-8"))
    except Exception:
        logger.warning("Could not parse history file, starting fresh.")
        return []


def save_history_entry(entry: Dict[str, Any]) -> None:
    history = _load_history()
    entry["timestamp"] = datetime.now().isoformat(timespec="seconds")
    history.insert(0, entry)
    HISTORY_FILE.write_text(
        json.dumps(history[:200], ensure_ascii=False, indent=2), encoding="utf-8"
    )


def get_history(limit: int = 50) -> List[Dict[str, Any]]:
    return _load_history()[:limit]


# --------------------------------------------------------------------------- #
# Image helpers
# --------------------------------------------------------------------------- #

def make_thumbnail(video_path: Path, out_path: Optional[Path] = None) -> Path:
    """Extract the first frame of a video as a PNG thumbnail using OpenCV."""
    import cv2

    out_path = out_path or video_path.with_suffix(".thumbnail.png")
    cap = cv2.VideoCapture(str(video_path))
    ok, frame = cap.read()
    cap.release()
    if not ok:
        raise RuntimeError(f"Could not read a frame from {video_path}")
    cv2.imwrite(str(out_path), frame)
    return out_path


def resize_to_multiple(image, multiple: int = 8):
    """Resize a PIL image so both dimensions are multiples of `multiple`,
    which most video diffusion VAEs require.
    """
    w, h = image.size
    new_w = max(multiple, (w // multiple) * multiple)
    new_h = max(multiple, (h // multiple) * multiple)
    if (new_w, new_h) != (w, h):
        image = image.resize((new_w, new_h))
    return image


def gpu_summary_string() -> str:
    from config import detect_gpu, get_quality_preset

    gpu = detect_gpu()
    preset = get_quality_preset(gpu)
    if gpu.tier == "cpu":
        return "⚠️ No GPU detected — running on CPU (slow, low quality preset)."
    return (
        f"🖥️ GPU: {gpu.name} ({gpu.vram_gb} GB, tier={gpu.tier}) — "
        f"max res {preset.max_resolution[0]}x{preset.max_resolution[1]}, "
        f"up to {preset.max_frames} frames, {preset.max_steps} steps max."
    )
