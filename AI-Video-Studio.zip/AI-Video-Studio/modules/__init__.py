"""AI Video Studio - modular pipeline package."""
