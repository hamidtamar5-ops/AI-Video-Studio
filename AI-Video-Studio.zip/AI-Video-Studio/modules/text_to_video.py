"""
modules/text_to_video.py
=========================
Text-to-Video pipeline wrapper.

This module wraps a Hugging Face `diffusers` video pipeline behind a small,
stable interface (`TextToVideoGenerator.generate(...)`) so the rest of the
app (Gradio UI, scene generator) never has to know which underlying model
(Wan 2.1 / CogVideoX / LTX-Video / HunyuanVideo) is actually loaded.

The active model is picked from `config.MODEL_REGISTRY` /
`config.ACTIVE_TEXT2VIDEO_MODEL`, so switching models is a one-line config
change with no changes needed elsewhere in the codebase.

Memory optimizations (xFormers, CPU offload, VAE slicing/tiling, attention
slicing) are applied automatically based on the detected GPU tier
(`config.get_quality_preset`).
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Callable, Optional

from config import (
    ACTIVE_TEXT2VIDEO_MODEL,
    MODEL_REGISTRY,
    detect_gpu,
    get_quality_preset,
)
from modules.utils import Timer, set_seed, unique_path

logger = logging.getLogger("ai_video_studio.text_to_video")

ProgressCallback = Optional[Callable[[float, str], None]]


class TextToVideoGenerator:
    """Loads and runs a text-to-video diffusion pipeline.

    The pipeline is loaded lazily on first `.generate()` call (not at import
    time) so the Gradio app can boot instantly and only pay the model-load
    cost once the user actually requests a generation.
    """

    def __init__(self, model_key: str = ACTIVE_TEXT2VIDEO_MODEL):
        if model_key not in MODEL_REGISTRY:
            raise ValueError(f"Unknown model '{model_key}'. "
                              f"Available: {list(MODEL_REGISTRY)}")
        self.model_key = model_key
        self.model_info = MODEL_REGISTRY[model_key]
        self.gpu = detect_gpu()
        self.preset = get_quality_preset(self.gpu)
        self._pipe = None

    # ------------------------------------------------------------------ #
    # Lazy pipeline loading
    # ------------------------------------------------------------------ #

    def _load_pipeline(self):
        if self._pipe is not None:
            return self._pipe

        import torch
        from diffusers import DiffusionPipeline

        dtype_map = {
            "float16": torch.float16,
            "bfloat16": torch.bfloat16,
            "float32": torch.float32,
        }
        torch_dtype = dtype_map.get(self.preset.dtype, torch.float16)

        with Timer(f"Loading {self.model_info['repo_id']} ({self.preset.dtype})"):
            pipe = DiffusionPipeline.from_pretrained(
                self.model_info["repo_id"],
                torch_dtype=torch_dtype,
            )

        self._apply_memory_optimizations(pipe)
        self._pipe = pipe
        return pipe

    def _apply_memory_optimizations(self, pipe) -> None:
        """Enable xFormers / CPU offload / VAE slicing / attention slicing
        automatically, matching the detected GPU tier's preset.
        """
        if self.preset.enable_xformers:
            try:
                pipe.enable_xformers_memory_efficient_attention()
                logger.info("xFormers memory-efficient attention enabled.")
            except Exception as e:
                logger.warning("xFormers unavailable, skipping (%s).", e)

        if self.preset.enable_attention_slicing and hasattr(pipe, "enable_attention_slicing"):
            pipe.enable_attention_slicing()

        if self.preset.enable_vae_slicing and hasattr(pipe, "enable_vae_slicing"):
            pipe.enable_vae_slicing()

        if self.preset.enable_vae_tiling and hasattr(pipe, "enable_vae_tiling"):
            pipe.enable_vae_tiling()

        if self.preset.enable_cpu_offload and hasattr(pipe, "enable_model_cpu_offload"):
            pipe.enable_model_cpu_offload()
        elif hasattr(pipe, "to"):
            import torch
            pipe.to("cuda" if torch.cuda.is_available() else "cpu")

    # ------------------------------------------------------------------ #
    # Generation
    # ------------------------------------------------------------------ #

    def generate(
        self,
        prompt: str,
        negative_prompt: str = "",
        seed: int = -1,
        width: int = 512,
        height: int = 512,
        num_frames: int = 49,
        fps: int = 24,
        guidance_scale: float = 6.0,
        num_inference_steps: int = 25,
        output_path: Optional[Path] = None,
        progress_cb: ProgressCallback = None,
    ) -> Path:
        """Generate a video from a text prompt and export it as MP4.

        Resolution/frames/steps are clamped to the current GPU's quality
        preset so the app never OOMs on a free-tier T4.
        """
        width = min(width, self.preset.max_resolution[0])
        height = min(height, self.preset.max_resolution[1])
        num_frames = min(num_frames, self.preset.max_frames)
        num_inference_steps = min(num_inference_steps, self.preset.max_steps)

        effective_seed = set_seed(seed)
        pipe = self._load_pipeline()

        import torch
        generator = torch.Generator(
            device="cuda" if torch.cuda.is_available() else "cpu"
        ).manual_seed(effective_seed)

        def _hf_progress(step: int, timestep: int, latents) -> None:
            if progress_cb:
                progress_cb(step / max(num_inference_steps, 1),
                            f"Denoising step {step}/{num_inference_steps}")

        with Timer(f"Text-to-video generation ({num_frames} frames @ {width}x{height})"):
            result = pipe(
                prompt=prompt,
                negative_prompt=negative_prompt or None,
                height=height,
                width=width,
                num_frames=num_frames,
                guidance_scale=guidance_scale,
                num_inference_steps=num_inference_steps,
                generator=generator,
                callback=_hf_progress if hasattr(pipe, "__call__") else None,
                callback_steps=1,
            )

        frames = result.frames[0]

        from diffusers.utils import export_to_video
        output_path = output_path or unique_path(Path("outputs"), "video", ".mp4")
        export_to_video(frames, str(output_path), fps=fps)
        logger.info("Saved text-to-video output to %s (seed=%s)", output_path, effective_seed)
        return output_path

    def unload(self) -> None:
        """Free VRAM by dropping the pipeline reference."""
        self._pipe = None
        try:
            import torch
            torch.cuda.empty_cache()
        except Exception:
            pass
