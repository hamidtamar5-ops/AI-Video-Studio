"""
modules/character.py
=====================
Character consistency management.

Video diffusion models generate each clip somewhat independently, so keeping
the "same person" across scenes requires anchoring generation to a shared
reference: a stored reference image plus a locked textual description of the
face, clothes, hairstyle, background and color palette. This module:

    - Saves/loads named character reference sheets (image + description) to
      `assets/characters/<name>/`.
    - Builds a consistency prompt fragment that is appended to every scene
      prompt using that character, so the model is repeatedly conditioned on
      the same descriptive details.
    - Optionally passes the reference image itself as conditioning to
      pipelines that support IP-Adapter / image-conditioning (used
      automatically by `SceneGenerator` when available).
"""

from __future__ import annotations

import json
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Optional

from config import CHARACTERS_DIR


@dataclass
class Character:
    name: str
    description: str = ""
    face: str = ""
    clothes: str = ""
    hairstyle: str = ""
    background: str = ""
    color_palette: str = ""
    reference_image_path: Optional[str] = None

    def to_prompt_fragment(self) -> str:
        """Build the text fragment appended to scene prompts to anchor
        consistency (same face / clothes / hair / palette across scenes).
        """
        parts = [p for p in [
            self.description,
            f"face: {self.face}" if self.face else "",
            f"wearing {self.clothes}" if self.clothes else "",
            f"{self.hairstyle} hairstyle" if self.hairstyle else "",
            f"{self.color_palette} color palette" if self.color_palette else "",
        ] if p]
        if not parts:
            return f"character named {self.name}, consistent appearance across scenes"
        return f"{self.name}: " + ", ".join(parts) + ", consistent appearance across all scenes"


class CharacterManager:
    """Handles persistence of characters under assets/characters/<name>/."""

    def __init__(self, base_dir: Path = CHARACTERS_DIR):
        self.base_dir = base_dir
        self.base_dir.mkdir(parents=True, exist_ok=True)

    def _dir_for(self, name: str) -> Path:
        safe_name = "".join(c for c in name if c.isalnum() or c in ("-", "_")) or "character"
        path = self.base_dir / safe_name
        path.mkdir(parents=True, exist_ok=True)
        return path

    def save(self, character: Character, reference_image=None) -> Character:
        """Save a character's metadata and optionally its reference image.
        `reference_image` may be a PIL.Image, a file path, or None.
        """
        char_dir = self._dir_for(character.name)

        if reference_image is not None:
            img_path = char_dir / "reference.png"
            if hasattr(reference_image, "save"):  # PIL.Image
                reference_image.save(img_path)
            else:  # path-like
                from shutil import copyfile
                copyfile(str(reference_image), img_path)
            character.reference_image_path = str(img_path)

        meta_path = char_dir / "character.json"
        meta_path.write_text(
            json.dumps(asdict(character), ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        return character

    def load(self, name: str) -> Optional[Character]:
        char_dir = self._dir_for(name)
        meta_path = char_dir / "character.json"
        if not meta_path.exists():
            return None
        data = json.loads(meta_path.read_text(encoding="utf-8"))
        return Character(**data)

    def list_characters(self) -> list[str]:
        return sorted(
            p.name for p in self.base_dir.iterdir()
            if p.is_dir() and (p / "character.json").exists()
        )

    def delete(self, name: str) -> bool:
        char_dir = self._dir_for(name)
        if not char_dir.exists():
            return False
        import shutil
        shutil.rmtree(char_dir)
        return True
